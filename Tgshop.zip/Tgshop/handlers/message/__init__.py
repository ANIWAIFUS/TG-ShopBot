from handlers.message.user_message import dp
from handlers.message.admin_message import dp
from handlers.message.other_message import dp

__all__ = ["dp"]
